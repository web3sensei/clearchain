console.log("Telemetry is disabled");
